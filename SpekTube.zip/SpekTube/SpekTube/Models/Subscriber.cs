﻿namespace SpekTube.Models
{
    public class Subscriber
    {
        public int Id { get; set; }
        public int UserID_FK {  get; set; } 
        public int ChannelID_FK { get; set; }


    }
}
