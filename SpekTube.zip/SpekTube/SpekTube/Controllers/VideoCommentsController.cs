﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SpekTube.Models;

namespace SpekTube.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VideoCommentsController : Controller
    {
        private readonly SpekTubeDbContext _dbContext;

        public VideoCommentsController(SpekTubeDbContext context)
        {
            _dbContext = context;
        }

        [HttpGet]
        public ActionResult Getvideo_Comment()
        {
            if (_dbContext.Video_Comments == null)
            {
                return NotFound();
            }
            return Ok(_dbContext.Video_Comments.ToList());
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<VideoComment>> GetvideoComment(int id)
        {
            if (_dbContext.Video_Comments == null)
            {
                return NotFound();
            }
            var obj = await _dbContext.Video_Comments.FindAsync(id);

            if (obj == null)
            {
                return NotFound();
            }
            return obj;
        }


        [HttpPut]
        public IActionResult PutVideoComment(VideoComment vCommentDetails)
        {
            if (_dbContext.Video_Comments == null)
            {
                return Problem("null.");
            }       
            _dbContext.Video_Comments.Add(vCommentDetails);
            _dbContext.SaveChanges();
            return Ok(new { message = "Comment added." });
        }

    }
}
